/**
 * @nextrush/router - Router Implementation
 *
 * High-performance router using a segment trie for route matching.
 * Routes are keyed by full path segments (e.g. "users", ":id"), not by
 * individual characters — this is a segment-based trie, not a compressed
 * radix tree. Supports parameters, wildcards, and method-based routing.
 *
 * @packageDocumentation
 */

import {
    HTTP_METHODS,
    type Context,
    type HttpMethod,
    type MetadataContribution,
    type Middleware,
    type RouteDefinition,
    type RouteEntry,
    type RouteHandler,
    type RouteMatch,
    type RouterOptions,
} from '@nextrush/types';
import {
    compileExecutor,
    createNode,
    NodeType,
    NOOP_NEXT,
    parseSegments,
    type HandlerEntry,
    type RadixNode,
} from './radix-tree';
import { createRedirectHandler, type RedirectStatus } from './redirect';
import { GroupRouter, type RouteGroup } from './group-router';
import { mergeContributions, readContribution } from './route-metadata';

/** Frozen empty params for static routes — avoids allocation per request */
const EMPTY_PARAMS: Record<string, string> = Object.freeze(
  Object.create(null) as Record<string, string>
);

/**
 * Inline route metadata declaration — re-exported from its own module (RT-3).
 */
export { endpoint } from './route-metadata';

/**
 * Router class — high-performance segment trie router
 *
 * Routes are indexed by path segment, giving O(d) lookup where d is the
 * number of segments. Static routes are additionally stored in a hash map
 * for O(1) fast-path lookup.
 *
 * @example
 * ```typescript
 * const router = createRouter();
 *
 * router.get('/users', listUsers);
 * router.get('/users/:id', getUser);
 * router.post('/users', createUser);
 *
 * app.use(router.routes());
 * ```
 */
export class Router {
  private readonly root: RadixNode;
  private readonly opts: Required<RouterOptions>;
  private readonly routerMiddleware: Middleware[] = [];

  /**
   * Static route hash map for O(1) lookup.
   * Key: "METHOD path" (e.g. "GET /users"), Value: HandlerEntry
   */
  private readonly staticRoutes = new Map<string, HandlerEntry>();

  /**
   * Introspection registry: every registered route as a RouteDefinition.
   * Kept SEPARATE from the hot-path structures (radix tree + staticRoutes) so
   * request dispatch never reads metadata — only getRoutes() (at doc-generation
   * time) touches this.
   */
  private readonly routeDefinitions: RouteDefinition[] = [];

  /** Whether any routes have params or wildcards (disables static-only fast path) */
  private hasParamRoutes = false;

  /** Whether router-level middleware has already been sealed into executors (audit RT-7) */
  private _sealed = false;

  constructor(options: RouterOptions = {}) {
    this.root = createNode('');
    this.opts = {
      prefix: options.prefix ?? '',
      caseSensitive: options.caseSensitive ?? false,
      strict: options.strict ?? false,
      decode: options.decode ?? true,
    };
  }

  /**
   * Normalize path based on router options
   */
  private normalizePath(path: string): string {
    // Handle prefix with trailing slash and path with leading slash
    let prefix = this.opts.prefix;
    if (prefix.endsWith('/') && path.startsWith('/')) {
      prefix = prefix.slice(0, -1);
    }

    let normalized = prefix + path;

    // Fast-path: skip regex when no double slashes (99%+ of requests)
    if (normalized.includes('//')) {
      normalized = normalized.replace(/\/+/g, '/');
    }

    // For non-strict mode during registration, remove trailing slash
    if (!this.opts.strict && normalized.length > 1 && normalized.endsWith('/')) {
      normalized = normalized.slice(0, -1);
    }

    return normalized.startsWith('/') ? normalized : '/' + normalized;
  }

  /**
   * Add a route to the radix tree
   */
  private addRoute(
    method: HttpMethod,
    path: string,
    entries: RouteEntry[],
    middleware: Middleware[] = []
  ): void {
    // Runtime guard for untyped JS callers — without this, a non-string path is
    // silently coerced (`'' + null` → 'null') into a bogus literal route.
    const rawPath: unknown = path;
    if (typeof rawPath !== 'string') {
      throw new TypeError(
        `Route path must be a string, received ${rawPath === null ? 'null' : typeof rawPath}.`
      );
    }
    const normalized = this.normalizePath(path);
    const segments = parseSegments(normalized, this.opts.caseSensitive);

    let node = this.root;

    for (const seg of segments) {
      if (seg.type === NodeType.PARAM) {
        if (!node.paramChild) {
          node.paramChild = createNode(seg.segment, NodeType.PARAM);
          node.paramChild.paramName = seg.paramName;
        } else if (node.paramChild.paramName !== seg.paramName) {
          // Same position, different param names — this silently loses one name
          // at runtime (params[newName] is undefined), so fail fast at
          // registration rather than warn (audit RT-5). Also removes the
          // process.env / console.warn usage that was here.
          throw new Error(
            `Route param name conflict at "${normalized}": ":${String(seg.paramName)}" ` +
              `conflicts with existing ":${String(node.paramChild.paramName)}" at the same ` +
              `position. Use the same param name for this segment across all routes.`
          );
        }
        node = node.paramChild;
      } else if (seg.type === NodeType.WILDCARD) {
        node.wildcardChild ??= createNode('*', NodeType.WILDCARD);
        node = node.wildcardChild;
        break; // Wildcard must be last
      } else {
        const key = seg.segment;
        let child = node.children.get(key);
        if (!child) {
          child = createNode(seg.segment, NodeType.STATIC);
          node.children.set(key, child);
        }
        node = child;
      }
    }

    // Partition entries: functions are behavior (inline middleware + the final
    // handler); pure markers (endpoint()) contribute metadata only and never
    // execute. Every entry may also carry a metadata contribution (e.g. a
    // function like validate() that both runs and contributes its schema).
    const functions: Middleware[] = [];
    const contributions: MetadataContribution[] = [];
    for (const routeEntry of entries) {
      const contribution = readContribution(routeEntry);
      if (contribution) contributions.push(contribution);
      if (typeof routeEntry === 'function') functions.push(routeEntry);
    }

    // Combine functions into a single handler with inline middleware
    const combinedMiddleware = [...middleware];
    const finalHandler: RouteHandler | undefined = functions[functions.length - 1];

    if (!finalHandler) {
      throw new Error('At least one handler is required');
    }

    // Inline middleware = every function before the last
    for (let i = 0; i < functions.length - 1; i++) {
      const fn = functions[i];
      if (fn) combinedMiddleware.push(fn);
    }

    // Pre-compile executor at registration time (not per-request!)
    const executor = compileExecutor(finalHandler, combinedMiddleware);

    const handlerEntry: HandlerEntry = {
      handler: finalHandler,
      middleware: combinedMiddleware,
      executor,
    };

    // Detect duplicate route registration
    if (node.handlers.has(method)) {
      throw new Error(
        `Route conflict: ${method} ${normalized} is already registered. ` +
          'Remove the duplicate or use a different path.'
      );
    }

    node.handlers.set(method, handlerEntry);

    // Populate static route hash map for O(1) lookup
    const hasParams = segments.some(
      (s) => s.type === NodeType.PARAM || s.type === NodeType.WILDCARD
    );
    if (hasParams) {
      this.hasParamRoutes = true;
    } else {
      const normalizedKey = this.opts.caseSensitive ? normalized : normalized.toLowerCase();
      this.staticRoutes.set(`${method} ${normalizedKey}`, handlerEntry);
    }

    // Record in the introspection registry (side structure — never touched by
    // request dispatch). key is the canonical `${METHOD} ${pathPattern}`.
    this.routeDefinitions.push({
      key: `${method} ${normalized}`,
      method,
      path: normalized,
      metadata: mergeContributions(contributions),
    });
  }

  // ===========================================================================
  // HTTP Method Shortcuts
  // ===========================================================================

  get(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('GET', path, entries);
    return this;
  }

  post(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('POST', path, entries);
    return this;
  }

  put(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('PUT', path, entries);
    return this;
  }

  delete(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('DELETE', path, entries);
    return this;
  }

  patch(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('PATCH', path, entries);
    return this;
  }

  head(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('HEAD', path, entries);
    return this;
  }

  options(path: string, ...entries: RouteEntry[]): this {
    this.addRoute('OPTIONS', path, entries);
    return this;
  }

  all(path: string, ...entries: RouteEntry[]): this {
    for (const method of HTTP_METHODS) {
      this.addRoute(method, path, entries);
    }
    return this;
  }

  route(method: HttpMethod, path: string, ...entries: RouteEntry[]): this {
    this.addRoute(method, path, entries);
    return this;
  }

  /**
   * Return every registered route as a read-only list of RouteDefinitions.
   *
   * Consumed by renderers (`@nextrush/openapi`, and future SDK/Postman/RPC
   * generators). This is a doc-generation-time projection of the introspection
   * registry — the request hot path never calls it.
   */
  getRoutes(): readonly RouteDefinition[] {
    return this.routeDefinitions;
  }

  /**
   * Register a redirect route from one path to another
   *
   * @param from - Source path to redirect from
   * @param to - Target path or URL to redirect to
   * @param status - HTTP status code (default: 301 permanent redirect)
   * @returns this for chaining
   *
   * @example
   * ```typescript
   * // Permanent redirect (301)
   * router.redirect('/old-page', '/new-page');
   *
   * // Temporary redirect (302)
   * router.redirect('/temp', '/destination', 302);
   *
   * // Redirect to external URL
   * router.redirect('/docs', 'https://docs.example.com');
   *
   * // With parameters - redirects /users/:id to /profiles/:id
   * router.redirect('/users/:id', '/profiles/:id');
   * ```
   */
  redirect(from: string, to: string, status: RedirectStatus = 301): this {
    const redirectHandler = createRedirectHandler(to, status);

    // Register for common methods. 307/308 preserve the original method,
    // so register all standard methods for those status codes.
    this.addRoute('GET', from, [redirectHandler]);
    this.addRoute('HEAD', from, [redirectHandler]);
    if (status === 307 || status === 308) {
      this.addRoute('POST', from, [redirectHandler]);
      this.addRoute('PUT', from, [redirectHandler]);
      this.addRoute('PATCH', from, [redirectHandler]);
      this.addRoute('DELETE', from, [redirectHandler]);
    }

    return this;
  }

  // ===========================================================================
  // Router Composition
  // ===========================================================================

  use(pathOrMiddleware: string | Middleware | Router, routerOrUndefined?: Router): this {
    if (typeof pathOrMiddleware === 'function') {
      // Middleware function
      this.routerMiddleware.push(pathOrMiddleware);
    } else if (typeof pathOrMiddleware === 'string' && routerOrUndefined instanceof Router) {
      // Mount sub-router at path
      this.mountRouter(pathOrMiddleware, routerOrUndefined);
    } else if (typeof pathOrMiddleware === 'string') {
      // String prefix without a Router — unsupported, throw clear error
      throw new Error(
        `router.use('${pathOrMiddleware}', ...) requires a Router instance as the second argument. ` +
          'Use router.group(prefix, callback) for prefix-scoped middleware, ' +
          'or router.use(middlewareFn) to register middleware without a prefix.'
      );
    } else if (pathOrMiddleware instanceof Router) {
      // Mount router at root
      this.mountRouter('', pathOrMiddleware);
    }
    return this;
  }

  /**
   * Mount a sub-router at a path prefix (Hono-style)
   *
   * This is the explicit API for mounting sub-routers.
   * Equivalent to `router.use(path, subRouter)` but more semantic.
   *
   * @param path - Path prefix for the sub-router
   * @param router - Router instance to mount
   * @returns this for chaining
   *
   * @example
   * ```typescript
   * // Create modular routers
   * const users = createRouter();
   * users.get('/', listUsers);
   * users.get('/:id', getUser);
   *
   * const posts = createRouter();
   * posts.get('/', listPosts);
   *
   * // Mount sub-routers
   * const api = createRouter();
   * api.mount('/users', users);
   * api.mount('/posts', posts);
   *
   * // Or use on main router
   * const router = createRouter();
   * router.mount('/api', api);
   *
   * app.use(router.routes());
   * ```
   */
  mount(path: string, router: Router): this {
    this.mountRouter(path, router);
    return this;
  }

  /**
   * Mount a sub-router (internal)
   *
   * Carries the sub-router's own `routerMiddleware` forward so that
   * `subrouter.use(mw)` middleware applies to every copied route.
   */
  private mountRouter(prefix: string, router: Router): void {
    this.copyRoutes(router.root, prefix, [], router.routerMiddleware);
  }

  /**
   * Recursively copy routes from another router
   */
  private copyRoutes(
    node: RadixNode,
    prefix: string,
    segments: string[],
    subRouterMiddleware: Middleware[]
  ): void {
    // Copy handlers at this node
    for (const [method, entry] of node.handlers) {
      const path = prefix + '/' + segments.join('/');
      // Prepend sub-router middleware so it runs before the route's own middleware
      const combined =
        subRouterMiddleware.length > 0
          ? [...subRouterMiddleware, ...entry.middleware]
          : entry.middleware;
      this.addRoute(method, path || '/', [entry.handler], combined);
    }

    // Copy static children
    for (const [, child] of node.children) {
      this.copyRoutes(child, prefix, [...segments, child.segment], subRouterMiddleware);
    }

    // Copy param child
    if (node.paramChild) {
      this.copyRoutes(
        node.paramChild,
        prefix,
        [...segments, node.paramChild.segment],
        subRouterMiddleware
      );
    }

    // Copy wildcard child
    if (node.wildcardChild) {
      this.copyRoutes(node.wildcardChild, prefix, [...segments, '*'], subRouterMiddleware);
    }
  }

  // ===========================================================================
  // Route Matching
  // ===========================================================================

  /**
   * Match a route and return handler + params
   */
  match(method: HttpMethod, path: string): RouteMatch | null {
    // Query string must not affect path matching (RFC 3986 §3.4). Strip it here
    // so both the normalized lookup path and extracted param values exclude it.
    const queryIdx = path.indexOf('?');
    if (queryIdx !== -1) path = path.slice(0, queryIdx);

    const isCaseInsensitive = !this.opts.caseSensitive;
    let normalized = isCaseInsensitive ? path.toLowerCase() : path;

    // Fast-path: skip regex when no double slashes (99%+ of requests)
    if (normalized.includes('//')) {
      normalized = normalized.replace(/\/+/g, '/');
    }

    // For strict mode, keep trailing slash; otherwise remove it
    if (!this.opts.strict && normalized.length > 1 && normalized.endsWith('/')) {
      normalized = normalized.slice(0, -1);
    }

    // FAST PATH: O(1) static route lookup (no tree traversal)
    // For static routes, trailing slash is irrelevant — always strip for lookup
    const staticKey =
      normalized.length > 1 && normalized.endsWith('/')
        ? `${method} ${normalized.slice(0, -1)}`
        : `${method} ${normalized}`;
    const staticEntry = this.staticRoutes.get(staticKey);
    if (staticEntry) {
      return {
        handler: staticEntry.handler,
        params: EMPTY_PARAMS,
        middleware: this.routerMiddleware,
        executor: staticEntry.executor,
      };
    }

    // Only walk tree if we have param/wildcard routes
    if (!this.hasParamRoutes) return null;

    // Use index-based path scanning instead of split('/').filter(Boolean)
    const params: Record<string, string> = {};

    // For case-insensitive mode, preserve original-case path for param values
    let originalPath: string | undefined;
    if (isCaseInsensitive) {
      originalPath = path;
      if (originalPath.includes('//')) {
        originalPath = originalPath.replace(/\/+/g, '/');
      }
      if (!this.opts.strict && originalPath.length > 1 && originalPath.endsWith('/')) {
        originalPath = originalPath.slice(0, -1);
      }
    }

    const result = this.matchNodeIndexed(
      this.root,
      normalized,
      1, // Start after leading '/'
      params,
      method,
      originalPath
    );
    if (!result) return null;

    // Check if any params were actually set
    let hasParams = false;
    for (const key of Object.keys(params)) {
      if (params[key] === undefined) {
        Reflect.deleteProperty(params, key);
      } else {
        hasParams = true;
      }
    }

    return {
      handler: result.handler,
      params: hasParams ? params : EMPTY_PARAMS,
      middleware: this.routerMiddleware,
      executor: result.executor,
    };
  }

  /**
   * Percent-decode an extracted param/wildcard value when `decode` is enabled.
   * Fast-paths values with no `%`, and falls back to the raw value on malformed
   * encoding (decodeURIComponent throws a URIError) so a bad request never crashes
   * routing.
   */
  private decodeParam(value: string): string {
    if (!this.opts.decode || !value.includes('%')) return value;
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }

  /**
   * Extract the next segment from path at given position without allocating arrays.
   * Returns [segment, nextIndex] where nextIndex is position after the trailing '/'.
   */
  private extractSegment(path: string, start: number): [segment: string, nextIndex: number] {
    const slashPos = path.indexOf('/', start);
    if (slashPos === -1) {
      return [path.slice(start), path.length];
    }
    return [path.slice(start, slashPos), slashPos + 1];
  }

  /**
   * Index-based recursive node matching (avoids array allocation)
   */
  private matchNodeIndexed(
    node: RadixNode,
    path: string,
    pos: number,
    params: Record<string, string>,
    method: HttpMethod,
    originalPath?: string
  ): HandlerEntry | null {
    // Reached end of path
    if (pos >= path.length) {
      return node.handlers.get(method) ?? null;
    }

    const [segment, nextPos] = this.extractSegment(path, pos);
    if (segment === '') return node.handlers.get(method) ?? null;

    // Try static match first (most specific)
    const staticChild = node.children.get(segment);
    if (staticChild) {
      const result = this.matchNodeIndexed(
        staticChild,
        path,
        nextPos,
        params,
        method,
        originalPath
      );
      if (result) return result;
    }

    // Try parameter match — use original-case segment for param value
    if (node.paramChild) {
      const paramName = node.paramChild.paramName;
      if (paramName === undefined) return null;
      if (originalPath) {
        const [origSeg] = this.extractSegment(originalPath, pos);
        params[paramName] = this.decodeParam(origSeg);
      } else {
        params[paramName] = this.decodeParam(segment);
      }
      const result = this.matchNodeIndexed(
        node.paramChild,
        path,
        nextPos,
        params,
        method,
        originalPath
      );
      if (result) return result;
      Reflect.deleteProperty(params, paramName);
    }

    // Try wildcard match (catches remaining path) — use original-case path
    if (node.wildcardChild) {
      const src = originalPath ?? path;
      params['*'] = this.decodeParam(src.slice(pos));
      return node.wildcardChild.handlers.get(method) ?? null;
    }

    return null;
  }

  // ===========================================================================
  // Middleware Generation
  // ===========================================================================

  /**
   * Get routes middleware function
   * Mount this on the application
   *
   * @example
   * ```typescript
   * app.use(router.routes());
   * ```
   */
  routes(): Middleware {
    // Seal router-level middleware into route executors at routes() call time
    // This avoids per-request closure creation
    const hasRouterMiddleware = this.routerMiddleware.length > 0;
    if (hasRouterMiddleware) {
      this.sealRouterMiddleware();
    }

    return async (ctx: Context, next?: () => Promise<void>): Promise<void> => {
      const match = this.match(ctx.method, ctx.path);

      if (!match) {
        // No route matched — set 404 so allowedMethods() and notFoundHandler() can act
        ctx.status = 404;
        if (next) await next();
        return;
      }

      // Set params on context
      ctx.params = match.params;

      // Use pre-compiled executor (includes router middleware if any)
      if (match.executor) {
        await match.executor(ctx);
        return;
      }

      // Fallback: No executor (shouldn't happen but be safe)
      await match.handler(ctx, NOOP_NEXT);
    };
  }

  /**
   * Re-compile all route executors to include router-level middleware.
   * Called once when routes() is invoked, not per-request.
   */
  private sealRouterMiddleware(): void {
    // Idempotent: sealing prepends routerMiddleware into every executor in
    // place, so running it twice would prepend the middleware twice (audit
    // RT-7). routes() can be invoked more than once (e.g. mounted and also
    // app.route()'d), so guard against re-sealing.
    if (this._sealed) return;
    this._sealed = true;

    const routerMw = [...this.routerMiddleware];

    // Walk the tree and re-compile every handler entry
    const walk = (node: RadixNode): void => {
      for (const [method, entry] of node.handlers) {
        const combinedMw = [...routerMw, ...entry.middleware];
        entry.executor = compileExecutor(entry.handler, combinedMw);
        node.handlers.set(method, entry);
      }
      for (const [, child] of node.children) {
        walk(child);
      }
      if (node.paramChild) walk(node.paramChild);
      if (node.wildcardChild) walk(node.wildcardChild);
    };

    walk(this.root);

    // Also update static route entries
    for (const [key, entry] of this.staticRoutes) {
      const combinedMw = [...routerMw, ...entry.middleware];
      entry.executor = compileExecutor(entry.handler, combinedMw);
      this.staticRoutes.set(key, entry);
    }
  }

  /**
   * Generate allowed methods middleware
   * Responds to OPTIONS and sets Allow header
   */
  allowedMethods(): Middleware {
    return async (ctx: Context, next?: () => Promise<void>): Promise<void> => {
      if (next) {
        await next();
      }

      if (ctx.status !== 404) return;

      // Single tree walk to find all allowed methods instead of N×match()
      const allowed = this.findAllowedMethods(ctx.path);

      if (allowed.length === 0) return;

      const allowHeader = allowed.join(', ');

      // If OPTIONS request, respond with allowed methods
      if (ctx.method === 'OPTIONS') {
        ctx.status = 200;
        ctx.set('Allow', allowHeader);
        ctx.body = '';
        return;
      }

      // Otherwise, return 405 Method Not Allowed
      ctx.status = 405;
      ctx.set('Allow', allowHeader);
    };
  }

  /**
   * Find all HTTP methods registered for a given path via single tree walk
   * @internal
   */
  private findAllowedMethods(path: string): HttpMethod[] {
    let normalized = this.opts.caseSensitive ? path : path.toLowerCase();

    if (normalized.includes('//')) {
      normalized = normalized.replace(/\/+/g, '/');
    }

    if (!this.opts.strict && normalized.length > 1 && normalized.endsWith('/')) {
      normalized = normalized.slice(0, -1);
    }

    const segments = normalized.split('/').filter(Boolean);
    const node = this.findNode(this.root, segments, 0);
    if (!node || node.handlers.size === 0) return [];

    return Array.from(node.handlers.keys());
  }

  /**
   * Walk the tree to find the node matching a path (ignoring HTTP method)
   * @internal
   */
  private findNode(node: RadixNode, segments: string[], index: number): RadixNode | null {
    if (index === segments.length) {
      return node;
    }

    const segment = segments[index];
    if (segment === undefined) return null;

    // Static match
    const staticChild = node.children.get(segment);
    if (staticChild) {
      const result = this.findNode(staticChild, segments, index + 1);
      if (result) return result;
    }

    // Param match
    if (node.paramChild) {
      const result = this.findNode(node.paramChild, segments, index + 1);
      if (result) return result;
    }

    // Wildcard match
    if (node.wildcardChild) {
      return node.wildcardChild;
    }

    return null;
  }

  // ===========================================================================
  // Route Groups
  // ===========================================================================

  /**
   * Create a route group with shared prefix and middleware
   *
   * @param prefix - Path prefix for all routes in the group
   * @param middlewareOrCallback - Middleware array or callback function
   * @param callback - Callback function if middleware is provided
   * @returns this for chaining
   *
   * @example
   * ```typescript
   * // Simple group with prefix
   * router.group('/api', (r) => {
   *   r.get('/users', listUsers);
   *   r.get('/posts', listPosts);
   * });
   *
   * // Group with middleware
   * router.group('/admin', [authMiddleware], (r) => {
   *   r.get('/dashboard', dashboard);
   *   r.post('/settings', updateSettings);
   * });
   *
   * // Nested groups
   * router.group('/api/v1', (r) => {
   *   r.group('/users', [rateLimit], (ur) => {
   *     ur.get('/', listUsers);
   *     ur.get('/:id', getUser);
   *   });
   * });
   * ```
   */
  group(
    prefix: string,
    middlewareOrCallback: Middleware[] | ((router: RouteGroup) => void),
    callback?: (router: RouteGroup) => void
  ): this {
    let middleware: Middleware[] = [];
    let cb: (router: RouteGroup) => void;

    if (Array.isArray(middlewareOrCallback)) {
      middleware = middlewareOrCallback;
      if (!callback) {
        throw new Error('Callback function is required when providing middleware array');
      }
      cb = callback;
    } else {
      cb = middlewareOrCallback;
    }

    // Collect the group's routes via a GroupRouter (RT-6: properly typed, no cast).
    const groupRouter = new GroupRouter(this, prefix, middleware);
    cb(groupRouter);

    return this;
  }

  /**
   * Remove all registered routes and middleware, resetting the router to its
   * initial state. Useful for test isolation or hot-reload scenarios that
   * need to re-register routes on the same router instance.
   */
  reset(): void {
    this.root.children.clear();
    this.root.handlers.clear();
    this.root.paramChild = undefined;
    this.root.wildcardChild = undefined;
    this.staticRoutes.clear();
    this.routerMiddleware.length = 0;
    this.hasParamRoutes = false;
    // Clear the introspection registry too, or getRoutes()/OpenAPI would emit
    // ghost routes after a reset (audit RT-1).
    this.routeDefinitions.length = 0;
    this._sealed = false;
  }

  /**
   * Internal method to add route with group context
   * @internal
   */
  _addGroupRoute(
    method: HttpMethod,
    path: string,
    handlers: RouteHandler[],
    groupMiddleware: Middleware[]
  ): void {
    this.addRoute(method, path, handlers, groupMiddleware);
  }
}

/**
 * Create a new Router instance
 *
 * @param options - Router options
 * @returns New Router instance
 *
 * @example
 * ```typescript
 * const router = createRouter();
 * const apiRouter = createRouter({ prefix: '/api/v1' });
 * ```
 */
export function createRouter(options?: RouterOptions): Router {
  return new Router(options);
}
