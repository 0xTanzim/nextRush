/**
 * @nextrush/errors - Error Factory
 *
 * Factory functions for creating errors.
 *
 * @packageDocumentation
 */

import { HttpError, NextRushError } from './base';
import {
  BadGatewayError,
  BadRequestError,
  ConflictError,
  ExpectationFailedError,
  FailedDependencyError,
  ForbiddenError,
  GatewayTimeoutError,
  GoneError,
  HttpVersionNotSupportedError,
  ImATeapotError,
  InsufficientStorageError,
  InternalServerError,
  LengthRequiredError,
  LockedError,
  LoopDetectedError,
  MethodNotAllowedError,
  NetworkAuthRequiredError,
  NotAcceptableError,
  NotExtendedError,
  NotFoundError,
  NotImplementedError,
  PayloadTooLargeError,
  PaymentRequiredError,
  PreconditionFailedError,
  PreconditionRequiredError,
  ProxyAuthRequiredError,
  RangeNotSatisfiableError,
  RequestHeaderFieldsTooLargeError,
  RequestTimeoutError,
  ServiceUnavailableError,
  TooEarlyError,
  TooManyRequestsError,
  UnauthorizedError,
  UnavailableForLegalReasonsError,
  UnprocessableEntityError,
  UnsupportedMediaTypeError,
  UpgradeRequiredError,
  UriTooLongError,
  VariantAlsoNegotiatesError,
  type HttpErrorOptions,
} from './http-errors';

/**
 * HTTP status code to error class mapping.
 *
 * @remarks
 * Covers every status that has a dedicated typed class so {@link createError}
 * returns the correctly-coded instance (audit E-3). `405` is handled separately
 * because {@link MethodNotAllowedError} has a divergent constructor signature.
 */
const ERROR_MAP: Record<number, new (message?: string, options?: HttpErrorOptions) => HttpError> = {
  400: BadRequestError,
  401: UnauthorizedError,
  402: PaymentRequiredError,
  403: ForbiddenError,
  404: NotFoundError,
  406: NotAcceptableError,
  407: ProxyAuthRequiredError,
  408: RequestTimeoutError,
  409: ConflictError,
  410: GoneError,
  411: LengthRequiredError,
  412: PreconditionFailedError,
  413: PayloadTooLargeError,
  414: UriTooLongError,
  415: UnsupportedMediaTypeError,
  416: RangeNotSatisfiableError,
  417: ExpectationFailedError,
  418: ImATeapotError,
  422: UnprocessableEntityError,
  423: LockedError,
  424: FailedDependencyError,
  425: TooEarlyError,
  426: UpgradeRequiredError,
  428: PreconditionRequiredError,
  429: TooManyRequestsError,
  431: RequestHeaderFieldsTooLargeError,
  451: UnavailableForLegalReasonsError,
  500: InternalServerError,
  501: NotImplementedError,
  502: BadGatewayError,
  503: ServiceUnavailableError,
  504: GatewayTimeoutError,
  505: HttpVersionNotSupportedError,
  506: VariantAlsoNegotiatesError,
  507: InsufficientStorageError,
  508: LoopDetectedError,
  510: NotExtendedError,
  511: NetworkAuthRequiredError,
};

/**
 * Create an HTTP error by status code
 */
export function createError(
  status: number,
  message?: string,
  options?: HttpErrorOptions
): HttpError {
  // Special case: MethodNotAllowedError requires allowedMethods array
  if (status === 405) {
    return new MethodNotAllowedError([], message, options);
  }

  const ErrorClass = ERROR_MAP[status];

  if (ErrorClass) {
    return new ErrorClass(message, options);
  }

  // Fallback: let HttpError constructor resolve the message via getHttpStatusMessage()
  return new HttpError(status, message, options);
}

/**
 * Create a 400 Bad Request error
 */
export function badRequest(message?: string, options?: HttpErrorOptions): BadRequestError {
  return new BadRequestError(message, options);
}

/**
 * Create a 401 Unauthorized error
 */
export function unauthorized(message?: string, options?: HttpErrorOptions): UnauthorizedError {
  return new UnauthorizedError(message, options);
}

/**
 * Create a 403 Forbidden error
 */
export function forbidden(message?: string, options?: HttpErrorOptions): ForbiddenError {
  return new ForbiddenError(message, options);
}

/**
 * Create a 404 Not Found error
 */
export function notFound(message?: string, options?: HttpErrorOptions): NotFoundError {
  return new NotFoundError(message, options);
}

/**
 * Create a 405 Method Not Allowed error
 */
export function methodNotAllowed(
  allowedMethods?: string[],
  message?: string,
  options?: HttpErrorOptions
): MethodNotAllowedError {
  return new MethodNotAllowedError(allowedMethods, message, options);
}

/**
 * Create a 409 Conflict error
 */
export function conflict(message?: string, options?: HttpErrorOptions): ConflictError {
  return new ConflictError(message, options);
}

/**
 * Create a 422 Unprocessable Entity error
 */
export function unprocessableEntity(
  message?: string,
  options?: HttpErrorOptions
): UnprocessableEntityError {
  return new UnprocessableEntityError(message, options);
}

/**
 * Create a 429 Too Many Requests error
 */
export function tooManyRequests(
  message?: string,
  options?: HttpErrorOptions & { retryAfter?: number }
): TooManyRequestsError {
  return new TooManyRequestsError(message, options);
}

/**
 * Create a 500 Internal Server Error
 */
export function internalError(message?: string, options?: HttpErrorOptions): InternalServerError {
  return new InternalServerError(message, options);
}

/**
 * Create a 502 Bad Gateway error
 */
export function badGateway(message?: string, options?: HttpErrorOptions): BadGatewayError {
  return new BadGatewayError(message, options);
}

/**
 * Create a 503 Service Unavailable error
 */
export function serviceUnavailable(
  message?: string,
  options?: HttpErrorOptions & { retryAfter?: number }
): ServiceUnavailableError {
  return new ServiceUnavailableError(message, options);
}

/**
 * Create a 504 Gateway Timeout error
 */
export function gatewayTimeout(message?: string, options?: HttpErrorOptions): GatewayTimeoutError {
  return new GatewayTimeoutError(message, options);
}

/**
 * Check if an error is a NextRush HttpError
 */
export function isHttpError(error: unknown): error is HttpError {
  return error instanceof HttpError;
}

/**
 * Get HTTP status from any error
 *
 * Checks NextRushError first (covers HttpError, ValidationError, and all subclasses),
 * then falls back to duck-typed status property.
 */
export function getErrorStatus(error: unknown): number {
  if (error instanceof NextRushError) {
    return error.status;
  }
  if (
    error != null &&
    typeof error === 'object' &&
    'status' in error &&
    typeof (error as { status: unknown }).status === 'number'
  ) {
    const status = (error as { status: number }).status;
    return status >= 400 && status < 600 ? status : 500;
  }
  return 500;
}

/**
 * Get error message safe for client response
 *
 * Exposes message for any NextRushError (including ValidationError)
 * when the error's expose flag is true.
 */
export function getSafeErrorMessage(error: unknown): string {
  if (error instanceof NextRushError && error.expose) {
    return error.message;
  }
  return 'Internal Server Error';
}
